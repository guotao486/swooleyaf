--
-- Created by IntelliJ IDEA.
-- User: jw
-- Date: 2018/3/13 0013
-- Time: 8:41
-- To change this template use File | Settings | File Templates.
--

local sywaf = require("sywaf")

symodules = {}
symodules.waf = sywaf