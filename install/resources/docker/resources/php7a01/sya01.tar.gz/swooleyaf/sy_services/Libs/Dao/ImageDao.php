<?php
/**
 * Created by PhpStorm.
 * User: 姜伟
 * Date: 2017/8/31 0031
 * Time: 9:53
 */
namespace Dao;

use Traits\SimpleDaoTrait;

class ImageDao {
    use SimpleDaoTrait;

    public static function uploadImage(array $data){
        return [];
    }
}