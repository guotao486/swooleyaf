<?php
namespace Entities\SyBase;

use DB\Entities\MysqlEntity;

class AlipayConfigEntity extends MysqlEntity {
    public function __construct(string $dbName='') {
        $this->_dbName = isset($dbName{0}) ? $dbName : 'sy_base';
        parent::__construct($this->_dbName, 'alipay_config','id');
    }

    /**
     * 主键ID
     * @var int
     */
    public $id = null;

    /**
     * app id
     * @var string
     */
    public $app_id = '';

    /**
     * 卖家ID
     * @var string
     */
    public $seller_id = '';

    /**
     * 异步消息通知URL
     * @var string
     */
    public $url_notify = '';

    /**
     * 同步消息通知URL
     * @var string
     */
    public $url_return = '';

    /**
     * rsa私钥，去除证书文件的第一行和最后一行以及所有换行
     * @var string
     */
    public $prikey_rsa = '';

    /**
     * rsa公钥，去除证书文件的第一行和最后一行以及所有换行
     * @var string
     */
    public $pubkey_rsa = '';

    /**
     * 支付宝公钥，去除证书文件的第一行和最后一行以及所有换行
     * @var string
     */
    public $pubkey_ali = '';

    /**
     * 状态
     * @var int
     */
    public $status = 1;

    /**
     * 创建时间戳
     * @var int
     */
    public $created = 0;

    /**
     * 修改时间戳
     * @var int
     */
    public $updated = 0;
}