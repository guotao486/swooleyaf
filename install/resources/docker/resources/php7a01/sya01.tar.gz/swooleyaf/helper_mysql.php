<?php
require_once __DIR__ . '/helper_load.php';

\Helper\MysqlTool::generator();