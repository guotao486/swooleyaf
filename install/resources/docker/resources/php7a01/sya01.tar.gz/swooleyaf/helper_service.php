<?php
require_once __DIR__ . '/helper_load.php';

\Helper\ServiceRunner::run(\Constant\Project::MODULE_NAME_API, \Constant\Project::$totalModuleName);