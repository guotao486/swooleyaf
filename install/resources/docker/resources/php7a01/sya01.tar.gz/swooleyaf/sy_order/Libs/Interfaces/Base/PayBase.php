<?php
/**
 * Created by PhpStorm.
 * User: 姜伟
 * Date: 2017/9/18 0018
 * Time: 14:42
 */
namespace Interfaces\Base;

abstract class PayBase {
    public $payType = '';

    public function __construct() {
    }
}