<?php
define('APP_PATH', __DIR__);