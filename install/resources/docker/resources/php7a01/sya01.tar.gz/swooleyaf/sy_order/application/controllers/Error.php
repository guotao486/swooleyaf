<?php
/**
 * Created by PhpStorm.
 * User: 姜伟
 * Date: 2017/3/15 0015
 * Time: 10:29
 */
class ErrorController extends \SyFrame\BaseErrorController {
    public function init(){
        parent::init();
    }
}