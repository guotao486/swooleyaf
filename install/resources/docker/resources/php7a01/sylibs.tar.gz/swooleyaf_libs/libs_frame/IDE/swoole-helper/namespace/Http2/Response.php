<?php
namespace Swoole\Http2;

/**
 * @since 1.10.4
 */
class Response
{



}
