<?php
/**
 * @param mixed $value
 * @return string
 */
function msgpack_serialize($value) {return '';}

/**
 * @param string $str
 * @param string $object
 * @return mixed
 */
function msgpack_unserialize(string $str, $object='') {}

/**
 * @param mixed $value
 * @return string
 */
function msgpack_pack($value) {return '';}

/**
 * @param string $str
 * @param string $object
 * @return mixed
 */
function msgpack_unpack(string $str, $object='') {}