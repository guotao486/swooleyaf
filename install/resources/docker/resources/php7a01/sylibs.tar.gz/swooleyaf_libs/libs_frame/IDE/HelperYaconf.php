<?php
namespace  {
    class Yaconf {
        /**
         * @param $name
         * @return mixed
         */
        public static function get($name){}

        /**
         * @param $name
         * @return bool
         */
        public static function has($name){}
    }
}

