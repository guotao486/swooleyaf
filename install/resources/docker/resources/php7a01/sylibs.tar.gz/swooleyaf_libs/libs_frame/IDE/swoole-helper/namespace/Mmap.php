<?php
namespace Swoole;

/**
 * @since 1.10.4
 */
class Mmap
{


    /**
     * @param $filename[required]
     * @param $size[optional]
     * @param $offset[optional]
     * @return mixed
     */
    public static function open($filename, $size=null, $offset=null){}


}
