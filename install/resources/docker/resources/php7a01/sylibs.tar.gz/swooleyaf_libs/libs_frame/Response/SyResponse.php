<?php
/**
 * Created by PhpStorm.
 * User: 姜伟
 * Date: 2017/8/23 0023
 * Time: 8:54
 */
namespace Response;

abstract class SyResponse {
    private function __construct() {
    }
}