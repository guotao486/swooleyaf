<?php
namespace Swoole\Websocket;

/**
 * @since 1.10.4
 */
class Frame
{



}
