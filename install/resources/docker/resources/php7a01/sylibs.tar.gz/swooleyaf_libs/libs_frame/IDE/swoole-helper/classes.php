<?php

class swoole_server extends Swoole\Server
{

}

class swoole_timer extends Swoole\Timer
{

}

class swoole_event extends Swoole\Event
{

}

class swoole_async extends Swoole\Async
{

}

class swoole_connection_iterator extends Swoole\Connection\Iterator
{

}

class swoole_exception extends Swoole\Exception
{

}

class swoole_server_port extends Swoole\Server\Port
{

}

class swoole_client extends Swoole\Client
{

}

class swoole_http_client extends Swoole\Http\Client
{

}

class swoole_process extends Swoole\Process
{

}

class swoole_table extends Swoole\Table
{

}

class swoole_table_row extends Swoole\Table\Row
{

}

class swoole_lock extends Swoole\Lock
{

}

class swoole_atomic extends Swoole\Atomic
{

}

class swoole_atomic_long extends Swoole\Atomic\Long
{

}

class swoole_http_server extends Swoole\Http\Server
{

}

class swoole_http_response extends Swoole\Http\Response
{

}

class swoole_http_request extends Swoole\Http\Request
{

}

class swoole_buffer extends Swoole\Buffer
{

}

class swoole_websocket_server extends Swoole\Websocket\Server
{

}

class swoole_websocket_frame extends Swoole\Websocket\Frame
{

}

class swoole_mysql extends Swoole\Mysql
{

}

class swoole_mysql_exception extends Swoole\Mysql\Exception
{

}

class swoole_mmap extends Swoole\Mmap
{

}

class swoole_channel extends Swoole\Channel
{

}

class swoole_http2_client extends Swoole\Http2\Client
{

}

class swoole_http2_response extends Swoole\Http2\Response
{

}

class swoole_serialize extends Swoole\Serialize
{

}

class swoole_redis_server extends Swoole\Redis\Server
{

}
