<?php
namespace Swoole;

/**
 * @since 1.10.4
 */
class Serialize
{


    /**
     * @param $data[required]
     * @param $flag[optional]
     * @return mixed
     */
    public static function pack($data, $flag=null){}

    /**
     * @param $string[required]
     * @param $args[optional]
     * @return mixed
     */
    public static function unpack($string, $args=null){}


}
